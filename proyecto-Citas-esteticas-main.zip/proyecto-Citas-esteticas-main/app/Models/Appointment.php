<?php

/**
 * AUTORES: Erick Cuevas- Camilo Ramirez
 * MATERIA: Arquitectura y Diseno de Software
 */

namespace App\Models;

use InvalidArgumentException;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Appointment extends Model
{
    use HasFactory;

    // ======================================================================
    // GUIA 1 - ACTIVIDAD 1: ESCENARIO DE NEGOCIO
    // La cita conecta cliente, negocio y servicio dentro del flujo central del sistema.
    // ======================================================================
    public const STATUS_PENDING = 'pending';
    public const STATUS_CONFIRMED = 'confirmed';
    public const STATUS_CANCELLED = 'cancelled';
    public const STATUS_COMPLETED = 'completed';
    public const PAYMENT_STATUS_PENDING_ADVANCE = 'pending_advance';
    public const PAYMENT_STATUS_PARTIALLY_PAID = 'partially_paid';
    public const PAYMENT_STATUS_PAID = 'paid';

    private const BUSINESS_STATUS_TRANSITIONS = [
        self::STATUS_PENDING => [
            self::STATUS_PENDING,
            self::STATUS_CONFIRMED,
            self::STATUS_CANCELLED,
        ],
        self::STATUS_CONFIRMED => [
            self::STATUS_CONFIRMED,
            self::STATUS_COMPLETED,
            self::STATUS_CANCELLED,
        ],
        self::STATUS_CANCELLED => [self::STATUS_CANCELLED],
        self::STATUS_COMPLETED => [self::STATUS_COMPLETED],
    ];

    private const CLIENT_STATUS_TRANSITIONS = [
        self::STATUS_PENDING => [
            self::STATUS_PENDING,
            self::STATUS_CANCELLED,
        ],
        self::STATUS_CONFIRMED => [
            self::STATUS_CONFIRMED,
            self::STATUS_CANCELLED,
        ],
        self::STATUS_CANCELLED => [self::STATUS_CANCELLED],
        self::STATUS_COMPLETED => [self::STATUS_COMPLETED],
    ];

    protected $fillable = [
        'user_id',
        'business_id',
        'service_id',
        'appointment_date',
        'start_time',
        'end_time',
        'service_price',
        'advance_percentage',
        'advance_amount',
        'payment_status',
        'status',
        'notes',
    ];

    public function user(): BelongsTo
    {
        // ======================================================================
        // GUIA 1 - ACTIVIDAD 2: MODELO CONCEPTUAL
        // La cita conserva la referencia al usuario que solicita o administra la reserva.
        // ======================================================================
        return $this->belongsTo(User::class);
    }

    public function business(): BelongsTo
    {
        // ======================================================================
        // GUIA 1 - ACTIVIDAD 2: MODELO CONCEPTUAL
        // La cita mantiene el enlace con el negocio donde se prestara el servicio.
        // ======================================================================
        return $this->belongsTo(Business::class);
    }

    public function service(): BelongsTo
    {
        // ======================================================================
        // GUIA 1 - ACTIVIDAD 2: MODELO CONCEPTUAL
        // La cita identifica el servicio reservado dentro del negocio.
        // ======================================================================
        return $this->belongsTo(Service::class);
    }

    public static function statuses(): array
    {
        return [
            self::STATUS_PENDING,
            self::STATUS_CONFIRMED,
            self::STATUS_CANCELLED,
            self::STATUS_COMPLETED,
        ];
    }

    public static function paymentStatuses(): array
    {
        return [
            self::PAYMENT_STATUS_PENDING_ADVANCE,
            self::PAYMENT_STATUS_PARTIALLY_PAID,
            self::PAYMENT_STATUS_PAID,
        ];
    }

    public static function allowedStatusesFor(User $user, ?string $currentStatus = null): array
    {
        if ($user->isAdmin()) {
            return self::statuses();
        }

        if ($user->isBusiness()) {
            return self::resolveAllowedStatuses($currentStatus, [
                self::STATUS_PENDING,
                self::STATUS_CONFIRMED,
            ], self::BUSINESS_STATUS_TRANSITIONS);
        }

        return self::resolveAllowedStatuses($currentStatus, [self::STATUS_PENDING], self::CLIENT_STATUS_TRANSITIONS);
    }

    protected function casts(): array
    {
        return [
            'appointment_date' => 'date',
            'service_price' => 'decimal:2',
            'advance_percentage' => 'decimal:2',
            'advance_amount' => 'decimal:2',
        ];
    }

    private static function resolveAllowedStatuses(?string $currentStatus, array $defaultStatuses, array $transitions): array
    {
        if ($currentStatus === null) {
            return $defaultStatuses;
        }

        return $transitions[$currentStatus]
            ?? throw new InvalidArgumentException('Estado de cita no soportado.');
    }
}
