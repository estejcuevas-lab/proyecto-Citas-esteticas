<?php

/**
 * AUTORES: Erick Cuevas- Camilo Ramirez
 * MATERIA: Arquitectura y Diseno de Software
 */

<?php

namespace App\Services;

use App\Models\Appointment;
use App\Models\Service;

class AppointmentPaymentService
{
    protected const DEFAULT_ADVANCE_PERCENTAGE = 50.00;

    public function buildPaymentData(Service $service, ?string $paymentStatus = null): array
    {
        $servicePrice = $this->normalizeAmount($service->price);
        $advancePercentage = self::DEFAULT_ADVANCE_PERCENTAGE;
        $advanceAmount = $this->calculateAdvanceAmount($servicePrice, $advancePercentage);

        return [
            'service_price' => $servicePrice,
            'advance_percentage' => $advancePercentage,
            'advance_amount' => $advanceAmount,
            'payment_status' => $paymentStatus ?: Appointment::defaultPaymentStatus(),
        ];
    }

    private function calculateAdvanceAmount(float $servicePrice, float $advancePercentage): float
    {
        return round($servicePrice * ($advancePercentage / 100), 2);
    }

    private function normalizeAmount(float|int|string $amount): float
    {
        return round((float) $amount, 2);
    }

    public static function defaultAdvancePercentage(): float
    {
        return self::DEFAULT_ADVANCE_PERCENTAGE;
    }
}
