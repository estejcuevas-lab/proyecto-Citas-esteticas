<?php

namespace App\Core\Entities;

class BusinessHourEntity
{
    private ?int $id;
    private int $businessId;
    private int $dayOfWeek;
    private string $opensAt;
    private string $closesAt;
    private bool $isActive;

    public function __construct(
        ?int $id,
        int $businessId,
        int $dayOfWeek,
        string $opensAt,
        string $closesAt,
        bool $isActive = true
    ) {
        $this->id = $id;
        $this->businessId = $businessId;
        $this->dayOfWeek = $dayOfWeek;
        $this->opensAt = $opensAt;
        $this->closesAt = $closesAt;
        $this->isActive = $isActive;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getBusinessId(): int
    {
        return $this->businessId;
    }

    public function getDayOfWeek(): int
    {
        return $this->dayOfWeek;
    }

    public function getOpensAt(): string
    {
        return $this->opensAt;
    }

    public function getClosesAt(): string
    {
        return $this->closesAt;
    }

    public function isActive(): bool
    {
        return $this->isActive;
    }
}