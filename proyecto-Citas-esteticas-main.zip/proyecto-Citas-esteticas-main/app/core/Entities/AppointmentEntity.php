<?php

namespace App\Core\Entities;

class AppointmentEntity
{
    private ?int $id;
    private int $userId;
    private int $businessId;
    private int $serviceId;
    private string $appointmentDate;
    private string $startTime;
    private string $endTime;
    private float $servicePrice;
    private float $advancePercentage;
    private float $advanceAmount;
    private string $paymentStatus;
    private string $status;
    private ?string $notes;

    public function __construct(
        ?int $id,
        int $userId,
        int $businessId,
        int $serviceId,
        string $appointmentDate,
        string $startTime,
        string $endTime,
        float $servicePrice,
        float $advancePercentage,
        float $advanceAmount,
        string $paymentStatus,
        string $status,
        ?string $notes = null
    ) {
        $this->id = $id;
        $this->userId = $userId;
        $this->businessId = $businessId;
        $this->serviceId = $serviceId;
        $this->appointmentDate = $appointmentDate;
        $this->startTime = $startTime;
        $this->endTime = $endTime;
        $this->servicePrice = $servicePrice;
        $this->advancePercentage = $advancePercentage;
        $this->advanceAmount = $advanceAmount;
        $this->paymentStatus = $paymentStatus;
        $this->status = $status;
        $this->notes = $notes;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getUserId(): int
    {
        return $this->userId;
    }

    public function getBusinessId(): int
    {
        return $this->businessId;
    }

    public function getServiceId(): int
    {
        return $this->serviceId;
    }

    public function getAppointmentDate(): string
    {
        return $this->appointmentDate;
    }

    public function getStartTime(): string
    {
        return $this->startTime;
    }

    public function getEndTime(): string
    {
        return $this->endTime;
    }

    public function getServicePrice(): float
    {
        return $this->servicePrice;
    }

    public function getAdvancePercentage(): float
    {
        return $this->advancePercentage;
    }

    public function getAdvanceAmount(): float
    {
        return $this->advanceAmount;
    }

    public function getPaymentStatus(): string
    {
        return $this->paymentStatus;
    }

    public function getStatus(): string
    {
        return $this->status;
    }

    public function getNotes(): ?string
    {
        return $this->notes;
    }

    public function isPending(): bool
    {
        return $this->status === 'pending';
    }

    public function isConfirmed(): bool
    {
        return $this->status === 'confirmed';
    }

    public function canBeCancelled(): bool
    {
        return in_array($this->status, ['pending', 'confirmed']);
    }
}